package com.github.manimovassagh.models.buldings;

/**
 * Define the room type. the room can be  single bed or double bed
 */
public enum SingleDouble {
    SINGLE, DOUBLEROOM
}
