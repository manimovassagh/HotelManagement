package com.github.manimovassagh.models.buldings;

/**
 * Define the Type of Room . In our Hotel we have VIP for Special Guests and Normal rooms for Ordinary Guests
 */
public enum RoomType {
    NORMAL,VIP
}
